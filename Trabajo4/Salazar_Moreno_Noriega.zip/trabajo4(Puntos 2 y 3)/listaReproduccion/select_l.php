<?php
 
// Create connection
require('../configuraciones/conexion.php');

//query
$query="SELECT * FROM lista_reproduccion WHERE codigoID != 0";
$result = mysqli_query($conn, $query) or 
die(mysqli_error($conn));
 

 
mysqli_close($conn);



?>
