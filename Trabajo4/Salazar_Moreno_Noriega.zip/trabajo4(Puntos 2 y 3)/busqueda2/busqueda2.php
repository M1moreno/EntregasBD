<!-- En esta pagina puede encontrar mas informacion acerca de la estructura de un documento html 
    http://www.iuma.ulpgc.es/users/jmiranda/docencia/Tutorial_HTML/estruct.htm-->
<!DOCTYPE html>
<html lang="en">
<!--cabecera del html -->

<head>
    <!--configuraciones basicas del html-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--titrulo de la pagina-->
    <title>inicio</title>
    <!--CDN de boostraps: Libreria de estilos SCSS y CSS para darle unas buena apariencia a la aplicacion
        para mas informacion buscar documentacion de boostraps en: https://getbootstrap.com/docs/4.3/getting-started/introduction/ -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--CDN de forntawesome: Libreria de estilos SCSS y CSS incluir iconos y formas 
         para mas informacion : https://fontawesome.com/start-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
</head>

<body>
    <!--Barra de navegacion-->
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link active" href="../index.html">inicio</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="../listaReproduccion/listaReproduccion.php">Listas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="../canciones/canciones.php">Canciones</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="../consultas/consultas.php">Consultas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="../busqueda1/busqueda1.php">Busqueda 1</a>
        </li>
        <li class="nav nav-pills">
            <a class="nav-link active" href="../busqueda2/busqueda2.php">Busqueda 2</a>
        </li>
    </ul>
    <div class="container">
        <div class="row my-2">
            <div class="col-6">
                <p>Ingrese las fechas en las que quiere buscar.</p>
                <form action="buscar2.php" target="_blank"  method="POST">
                    <div class="input-group ">
                        <div class="form-group">
                            <p>Fecha 1</p>
                            <input type="date" name="fecha1" id="fecha1" class="form-control">
                        </div>
                        <div class="form-group">
                            <p>Fecha 2</p>
                            <input type="date" name="fecha2" id="fecha2" class="form-control">
                        </div>
                    </div>
                    <button class="btn  btn-primary"  title="Buscar" type="submit">
                            <i class="fas fa-search-plus mx-0 my-0"> </i></button>
                </form>
            </div>
            
        </div>
    </div>
</body>

</html>